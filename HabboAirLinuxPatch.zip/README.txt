Instructions:
-Launch Habbo as executable 
-Enter the SSO ticket and press Enter

AIR SDK Version: 33.1.1.795

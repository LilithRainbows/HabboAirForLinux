Instructions:
-Launch Habbo as executable 
-Enter the SSO ticket and press Enter

AIR SDK Version: 50.2.2.4
